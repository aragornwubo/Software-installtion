WRK_DIR="ctg_pm_dir"
NUM_THREADS=20

oc2ctgpm.sh ${WRK_DIR} ${NUM_THREADS} contig.fasta ctg_pm.m4
