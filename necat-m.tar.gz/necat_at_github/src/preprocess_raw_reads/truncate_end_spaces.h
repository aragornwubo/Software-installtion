#ifndef __TRUNCATE_END_SPACES_H
#define __TRUNCATE_END_SPACES_H

#ifdef __cplusplus
extern "C" {
#endif

void truncate_end_spaces(char* line);

#ifdef __cplusplus
}
#endif

#endif // __TRUNCATE_END_SPACES_H