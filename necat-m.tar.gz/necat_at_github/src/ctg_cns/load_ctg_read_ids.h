#ifndef LOAD_CTG_READ_IDS_H
#define LOAD_CTG_READ_IDS_H

#include "../common/ontcns_aux.h"

u8* load_ctg_read_ids(const char* path, const int num_reads);

#endif // LOAD_CTG_READ_IDS_H