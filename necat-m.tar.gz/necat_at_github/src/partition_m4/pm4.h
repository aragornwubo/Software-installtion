#ifndef PM4_H
#define PM4_H

#include "pm4_options.h"

void
pm4_main(PM4Options* options, const char* wrk_dir, const char* m4_path);

#endif // PCAN_H
