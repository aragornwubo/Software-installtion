#ifndef GRAPH_HPP
#define GRAPH_HPP



namespace fsa {

template<typename N, typename E>
class Graph {
public:

};




} // namespace fsa {

#endif // GRAPH_HPP  