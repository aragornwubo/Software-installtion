#include "ontcns_aux.h"

int main()
{
    DGZ_OPEN(file, "ok.txt", "rb");
}
