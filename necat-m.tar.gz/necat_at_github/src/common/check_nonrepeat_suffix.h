#ifndef CHECK_NONREPEAT_SUFFIX_H
#define CHECK_NONREPEAT_SUFFIX_H

#ifdef __cplusplus
extern "C" {
#endif

#include "ontcns_defs.h"

int
is_nonrepeat_sequence(char* seq, const idx seq_ize);

#ifdef __cplusplus
}
#endif

#endif // CHECK_NONREPEAT_SUFFIX_H
