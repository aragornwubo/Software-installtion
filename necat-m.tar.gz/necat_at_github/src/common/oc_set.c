#include "oc_set.h"

#include "../klib/khash.h"

KHASH_SET_INIT_INT(int)
typedef khash_t(int) SetInt;


