#ifndef NST_NT4_TABLE_H
#define NST_NT4_TABLE_H

#include "ontcns_defs.h"

extern u8 nst_nt4_table[256];

#endif // NST_NT4_TABLE_H
